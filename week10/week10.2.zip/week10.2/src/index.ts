import { PrismaClient } from "@prisma/client"; // <--- standard location after generate


const prisma = new PrismaClient();

async function insertUser(
  username: string,
  password: string,
  firstName: string,
  lastName: string
) {
  const res = await prisma.user.create({
    data: {
      email: username,
      password,
      firstName,
      lastName,
    },
  });
  console.log(res);
}

(async () => {
  try {
    await insertUser("sudahnahu@gamil.com", "password", "jaja", "singh");
    await prisma.$disconnect(); // optional but good practice
  } catch (e) {
    console.error("❌ Error inserting user:", e);
    await prisma.$disconnect();
    process.exit(1);
  }
})();
